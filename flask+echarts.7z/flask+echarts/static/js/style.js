function getValue(id) { 
    return document.getElementById(id).value; 
} 
function checkuser() { 
    if(getValue('uname') == "stu1" && getValue('pwd') == "stu1") { 
        document.myform.action = "http://127.0.0.1:5000/stu1";   
        return true; 
    }
    else if(getValue('uname') == "stu2" && getValue('pwd') == "stu2") { 
        document.myform.action = "http://127.0.0.1:5000/stu2";   
        return true; 
    }
    else if(getValue('uname') == "stu3" && getValue('pwd') == "stu3") { 
        document.myform.action = "http://127.0.0.1:5000/stu3";   
        return true; 
    }
    else if(getValue('uname') == "stu4" && getValue('pwd') == "stu4") { 
        document.myform.action = "http://127.0.0.1:5000/stu4";   
        return true; 
    }
    else if(getValue('uname') == "stu5" && getValue('pwd') == "stu5") { 
        document.myform.action = "http://127.0.0.1:5000/stu5";   
        return true; 
    }
    else if(getValue('uname') == "stu6" && getValue('pwd') == "stu6") { 
        document.myform.action = "http://127.0.0.1:5000/stu6";   
        return true; 
    }
    else if(getValue('uname') == "stu7" && getValue('pwd') == "stu7") { 
        document.myform.action = "http://127.0.0.1:5000/stu7";   
        return true; 
    }
    else { 
        alert("登录名或密码错误！")
        return false; 
    } 
} 