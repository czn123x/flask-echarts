from flask import Flask, request, render_template, jsonify
import sqlite3
app = Flask(__name__) # 建立Flask应用
def get_db():#获得当前数据库连接
    db = sqlite3.connect('data.db')
    db.row_factory = sqlite3.Row
    return db
def query_db(query, args=(), one=False):#获得游标、执行查询和获取结果
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    rv = cur.fetchall()
    db.close()
    return (rv[0] if rv else None) if one else rv
@app.route("/")
def index():
        return render_template("界面.html")
@app.route("/对比分析")
def index1():
        return render_template("对比分析.html")
@app.route("/stu1")
def stu1():
        return render_template("stu1.html")
@app.route("/stu2")
def stu2():
        return render_template("stu2.html")
@app.route("/stu3")
def stu3():
        return render_template("stu3.html")
@app.route("/stu4")
def stu4():
        return render_template("stu4.html")
@app.route("/stu5")
def stu5():
        return render_template("stu5.html")
@app.route("/stu6")
def stu6():
        return render_template("stu6.html")
@app.route("/stu7")
def stu7():
        return render_template("stu7.html")



@app.route("/grade1")
def grade1():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade1")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )
@app.route("/grade2")
def grade2():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade2")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )
@app.route("/grade3")
def grade3():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade3")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )
@app.route("/grade4")
def grade4():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade4")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )
@app.route("/grade5")
def grade5():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade5")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )

@app.route("/grade6")
def grade6():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade6")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )
@app.route("/grade7")
def grade7():
        result = query_db("SELECT 科目,模拟分数,期末分数,学分 FROM grade7")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            模拟分数 = [x[1] for x in result],
            期末分数 = [x[2] for x in result],
            学分 = [x[3] for x in result],
        )


@app.route("/study1")
def study1():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study1")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study2")
def study2():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study2")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study3")
def study3():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study3")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study4")
def study4():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study4")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study5")
def study5():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study5")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study6")
def study6():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study6")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )
@app.route("/study7")
def study7():
        result = query_db("SELECT 时间,图书馆,教室,宿舍 FROM study7")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            图书馆 = [x[1] for x in result],
            教室 = [x[2] for x in result],
            宿舍 = [x[3] for x in result],
        )


@app.route("/bath1")
def bath1():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath1")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath2")
def bath2():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath2")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath3")
def bath3():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath3")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath4")
def bath4():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath4")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath5")
def bath5():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath5")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath6")
def bath6():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath6")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )
@app.route("/bath7")
def bath7():
        result = query_db("SELECT 时间,洗澡温度,洗澡水量,洗澡时长 FROM bath7")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            洗澡温度 = [x[1] for x in result],
            洗澡水量 = [x[2] for x in result],
            洗澡时长 = [x[3] for x in result],
        )



@app.route("/water1")
def water1():
        result = query_db("SELECT 时间,喝,其它 FROM water1")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water2")
def water2():
        result = query_db("SELECT 时间,喝,其它 FROM water2")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water3")
def water3():
        result = query_db("SELECT 时间,喝,其它 FROM water3")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water4")
def water4():
        result = query_db("SELECT 时间,喝,其它 FROM water4")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water5")
def water5():
        result = query_db("SELECT 时间,喝,其它 FROM water5")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water6")
def water6():
        result = query_db("SELECT 时间,喝,其它 FROM water6")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )
@app.route("/water7")
def water7():
        result = query_db("SELECT 时间,喝,其它 FROM water7")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            喝 = [x[1] for x in result],
            其它 = [x[2] for x in result],
        )



@app.route("/canteen1")
def canteen1():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen1")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen2")
def canteen2():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen2")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen3")
def canteen3():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen3")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen4")
def canteen4():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen4")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen5")
def canteen5():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen5")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen6")
def canteen6():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen6")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )
@app.route("/canteen7")
def canteen7():
        result = query_db("SELECT 时间,早餐用餐时长,午餐用餐时长,晚餐用餐时长 FROM canteen7")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            早餐用餐时长 = [x[1] for x in result],
            午餐用餐时长 = [x[2] for x in result],
            晚餐用餐时长 = [x[3] for x in result],
        )



@app.route("/sleep1")
def sleep1():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep1")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep2")
def sleep2():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep2")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep3")
def sleep3():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep3")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep4")
def sleep4():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep4")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep5")
def sleep5():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep5")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep6")
def sleep6():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep6")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )
@app.route("/sleep7")
def sleep7():
        result = query_db("SELECT 时间,晚上睡眠时长,中午睡眠时长 FROM sleep7")
        return jsonify(             #返回json数据
            时间 = [x[0] for x in result],
            晚上睡眠时长= [x[1] for x in result],
            中午睡眠时长= [x[2] for x in result],
        )


@app.route("/analyse1")
def analyse1():
        result = query_db("SELECT 科目,分析数据 FROM analyse1")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse2")
def analyse2():
        result = query_db("SELECT 科目,分析数据 FROM analyse2")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse3")
def analyse3():
        result = query_db("SELECT 科目,分析数据 FROM analyse3")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse4")
def analyse4():
        result = query_db("SELECT 科目,分析数据 FROM analyse4")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse5")
def analyse5():
        result = query_db("SELECT 科目,分析数据 FROM analyse5")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse6")
def analyse6():
        result = query_db("SELECT 科目,分析数据 FROM analyse6")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )
@app.route("/analyse7")
def analyse7():
        result = query_db("SELECT 科目,分析数据 FROM analyse7")
        return jsonify(             #返回json数据
            科目 = [x[0] for x in result],
            分析数据= [x[1] for x in result],
        )

@app.route("/ANALYSE")
def ANALYSE():
        result = query_db("SELECT 学生,生活习惯分,学习习惯分,行为习惯分,增分 FROM ANALYSE")
        return jsonify(             #返回json数据
            学生 = [x[0] for x in result],
            生活习惯分= [x[1] for x in result],
            学习习惯分= [x[2] for x in result],
            行为习惯分= [x[3] for x in result],
            增分= [x[4] for x in result],
        )



if __name__ == '__main__':
    app.debug = False
    app.run(host='127.0.0.1', port=5000)







